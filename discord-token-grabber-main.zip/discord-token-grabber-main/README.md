# discord-token-grabber
Discord token grabber

Simple token grabber, if issues, dm me
**DISCORD LINK CUZ WE ARE MADD EPIC XD: https://discord.gg/jsunuB9 **

i didnt code this, im not sure who really really coded it, but yeah, im not the real coder, just wanted to share
